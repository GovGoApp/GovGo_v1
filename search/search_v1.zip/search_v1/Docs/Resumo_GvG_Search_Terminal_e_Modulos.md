# GvG Search Terminal v2 (otimizado) — Visão geral, fluxo e funções

Este documento resume o sistema de busca PNCP da pasta `search/search_v1`, com foco no aplicativo de terminal (`GvG_Search_Terminal.py`) e em todos os módulos que ele importa. Inclui visão geral, fluxo ponta a ponta, lista de funções por arquivo, dependências e variáveis de ambiente.

---

## Sumário rápido
- 3 tipos de busca: Semântica, Palavras‑chave (FTS), Híbrida
- 3 abordagens: Direta, Correspondência por categorias, Filtro por categorias
- Processamento inteligente de queries (Assistant) com termos negativos/positivos e condições SQL
- Filtro de relevância (níveis 1–3) via Assistant para refinar a lista final
- Exportações: JSON, XLSX e PDF (opcional)
- Processamento de documentos (Docling → Markdown → Resumo por IA) com salvamento de arquivos
- Schema V1 consolidado (tabelas `contratacao`, `contratacao_emb`, `categoria`)

---

## Visão geral do sistema

- App interativo de terminal com Rich, em `GvG_Search_Terminal.py`.
- Núcleo de busca e categorias em `gvg_search_core.py`.
- Pré‑processamento inteligente e formatadores em `gvg_preprocessing.py`.
- Embeddings, negação e utilidades OpenAI em `gvg_ai_utils.py`.
- Banco/engine e documentos PNCP (via DB + API) em `gvg_database.py`.
- Exportação unificada em `gvg_exporters.py`.
- Processamento de documentos (Docling + OpenAI) em `gvg_documents.py`.
- Esquema centralizado e builders SQL em `gvg_schema.py`.
- Utilitários de manutenção em `gvg_search_maintenance.py`.
- Modos alternativos: execução única por CLI (`GvG_Search_Prompt.py`) e API programática (`GvG_Search_Function.py`).

Resultados retornam como lista de itens: `{'id','numero_controle','similarity','rank','details'}`.
`details` contém campos snake_case do schema V1, enriquecidos com aliases legados para compatibilidade.

---

## Fluxo principal (Terminal)

1) Entrada do usuário: digita consulta ou altera opções (tipo, abordagem, relevância, ordenação, toggles).
2) Pré‑processamento inteligente (se ativo): Assistant extrai `search_terms`, `negative_terms`, `sql_conditions`.
3) Categorias (se abordagem 2/3): `get_top_categories_for_query` usa embedding da query para TOP N categorias.
4) Busca principal (core):
   - Semântica (pgvector) ou
   - Palavras‑chave (FTS/tsvector) ou
   - Híbrida (combina vetorial + FTS; fallback mescla 2 listas).
5) Filtro de relevância (nível > 1): Assistant pode reordenar/filtrar a lista final por posições.
6) Ordenação final (UI): Similaridade, Data Encerramento ou Valor.
7) Exibição: tabela e painéis por item (Rich); destaques de termos e indicadores IA/negação.
8) Exportação: JSON/XLSX/PDF com nome padronizado.
9) Documentos: busca links (DB → API PNCP fallback), Docling converte, OpenAI resume, arquivos são salvos.

---

## Estados e configurações (Terminal)
- `current_search_type`: 1=Semântica, 2=Palavras‑chave, 3=Híbrida
- `current_search_approach`: 1=Direta, 2=Correspondência, 3=Filtro
- `current_sort_mode`: 1=Similaridade, 2=Data, 3=Valor
- `max_results`, `num_top_categories`
- `filter_expired` (default True), `use_negation_embeddings` (default True)
- IA: status/toggle via `gvg_search_core` (`get_intelligent_status`, `toggle_intelligent_*`)
- Relevância: nível via `set_relevance_filter_level`/`get_relevance_filter_status` (inicial ajustado para 2)
- Últimos resultados e categorias: `last_results`, `last_query`, `last_query_categories`

---

## Funções por arquivo

### `GvG_Search_Terminal.py`
- UI/menus: `display_header`, `display_menu`, `select_search_type`, `select_search_approach`, `select_relevance_level`, `select_sort_mode`, `configure_system`
- Busca: `perform_search`, `direct_search`, `correspondence_search`, `category_filtered_search`, `apply_sort_mode`
- Exibição: `display_results`, `display_result_details`, `highlight_key_terms`, `_display_top_categories_table`
- Documentos: `show_process_documents`, `process_documents_for_result`, `show_document_links`, `process_single_document`, `process_all_documents`, `display_document_summary`, `_build_pncp_data`
- Keywords: `generate_process_keywords`, `_generate_keywords_for_process`
- Exportação: `export_results`
- Loop: `main`

### `gvg_search_core.py`
- Busca: `semantic_search`, `keyword_search`, `hybrid_search`
- IA toggles/status: `toggle_intelligent_processing`, `toggle_intelligent_debug`, `get_intelligent_status`
- Relevância (Assistant): `set_relevance_filter_level`, `toggle_relevance_filter`, `get_relevance_filter_status`, `toggle_relevance_filter_debug`, `apply_relevance_filter`
- Categorias: `get_top_categories_for_query`, `correspondence_search`, `category_filtered_search`
- Helpers: `_get_processed`, `_augment_aliases`, `_ensure_vector_cast`, etc.

### `gvg_preprocessing.py`
- `SearchQueryProcessor` (thread + `process_query`, `_wait_for_response`, `_parse_response`)
- `process_search_query`
- Formatadores: `format_currency`, `format_date`, `decode_poder`, `decode_esfera`

### `gvg_ai_utils.py`
- `get_embedding`, `get_negation_embedding` (combina “positivo -- negativo”)
- `generate_keywords` (gpt‑3.5‑turbo)
- `calculate_confidence` (média 0–100)

### `gvg_database.py`
- `create_connection` (psycopg2), `create_engine_connection` (SQLAlchemy)
- `fetch_documentos` (tenta link no DB; fallback API PNCP `/arquivos`), `_parse_numero_controle_pncp`

### `gvg_exporters.py`
- `generate_export_filename`
- `export_results_json`, `export_results_excel`, `export_results_pdf` (se ReportLab instalado)

### `gvg_documents.py`
- Download/identificação: `download_document`, `detect_file_type_by_content_v3`, `is_zip_file`, `extract_all_supported_files_from_zip`, `extract_first_pdf_from_zip`
- Conversão/Resumo/Saves: `convert_document_to_markdown` (Docling FAST), `generate_document_summary` (gpt‑4o), `save_markdown_file`, `save_summary_file`, `process_pncp_document`, `summarize_document`
- Aux: `setup_openai`, `create_safe_filename`, `cleanup_temp_file`

### `gvg_schema.py`
- Constantes/metadados: tabelas, campos, vetores, FTS
- Builders SQL: `get_contratacao_core_columns`, `build_core_select_clause`, `build_semantic_select`, `build_category_similarity_select`
- Normalização/projeção: `normalize_contratacao_row`, `project_result_for_output`

### `gvg_search_maintenance.py`
- `sanity_check`, `index_advice`, `simple_benchmark`

### Modos alternativos
- `GvG_Search_Prompt.py`: execução única via CLI (`perform_search`, exportações, parse de args, `main`).
- `GvG_Search_Function.py`: API programática `gvg_search(...)` com exportações opcionais e retorno estruturado.
- `run_gvg_search_example.py`: exemplo mínimo de uso da função.

---

## Fluxo ponta a ponta (detalhado)

- Entrada → (IA) pré‑processador → termos positivos/negativos + condições SQL.
- Categorias (se necessário) → TOP N pelo embedding da query.
- Busca → SQL conforme tipo (pgvector/FTS/combinação) + filtros de data/condições.
- Relevância (nível 2/3) → Assistant recebe (query + descrições curtas) e devolve posições; lista é filtrada/reordenada.
- Ordenação final (UI) → exibição em tabela/painéis com destaques.
- Exportações (JSON/XLSX/PDF) → nomes padronizados com contexto (tipo/abordagem/relevância/ordem).
- Documentos → links (DB/API) → Docling → Markdown → Resumo (gpt‑4o) → arquivos salvos.

---

## Variáveis de ambiente e dependências

Principais variáveis (exemplos e nomes esperados):
- Banco (Supabase): `SUPABASE_HOST`, `SUPABASE_DBNAME` (ou `SUPABASE_DB_NAME`), `SUPABASE_USER`, `SUPABASE_PASSWORD`, `SUPABASE_PORT`
- OpenAI: `OPENAI_API_KEY`
- Assistants:
  - Pré‑processador: `GVG_PREPROCESSING_QUERY_v1`
  - Relevância (flex/restrict): `GVG_RELEVANCE_FLEXIBLE`, `GVG_RELEVANCE_RESTRICTIVE`
- Tuning/Debug: `NEGATION_EMB_WEIGHT`, `GVG_VECTOR_OPT`, `GVG_SQL_DEBUG`

Dependências (principais): `psycopg2`, `SQLAlchemy`, `pandas`, `numpy`, `rich`, `reportlab` (PDF opcional), `docling` (documentos), `openai`, `requests`, `python-dotenv`.

---

## Notas de compatibilidade e schema

- Schema V1 (snake_case) consolidado em `gvg_schema.py`: `contratacao`, `contratacao_emb`, `categoria`.
- `gvg_search_core` injeta aliases legados em `details` para manter compatibilidade com UI/export legados.
- Buscas respeitam filtro de expirados (datas em TEXT tratadas com `to_date` seguro).
- Categorias: similaridade contra `categoria.cat_embeddings`; resultados armazenam `top_category_info` quando aplicável.

---

## Referências úteis

- Terminal: `search/search_v1/GvG_Search_Terminal.py`
- Núcleo de busca: `search/search_v1/gvg_search_core.py`
- Pré‑processamento: `search/search_v1/gvg_preprocessing.py`
- Esquema: `search/search_v1/gvg_schema.py`
- Exportações: `search/search_v1/gvg_exporters.py`
- Documentos (Docling): `search/search_v1/gvg_documents.py`
- Banco/Engine/API: `search/search_v1/gvg_database.py`
- Manutenção: `search/search_v1/gvg_search_maintenance.py`
- CLI única: `search/search_v1/GvG_Search_Prompt.py`
- Função programática: `search/search_v1/GvG_Search_Function.py`
- Exemplo: `search/search_v1/run_gvg_search_example.py`

---

## Próximos passos sugeridos
- Validar `.env`/`supabase_v1.env` e conectividade ao banco.
- Rodar uma busca de teste (Terminal ou Prompt/Function) e exportar JSON para inspeção.
- Se usar relevância nível 2/3, confirmar os Assistant IDs por variável de ambiente.
- Para documentos, garantir `docling` instalado e caminhos de saída desejados (o módulo define diretórios base próprios).

---

## Integração com o Assistant de Pré‑Processamento e o Schema Supabase (BDS1)

Esta seção conecta o que o Assistente de pré‑processamento faz com o que o banco (BDS1) oferece, para que fique claro como o GvG forma as consultas SQL e filtra o universo.

### O que o Assistant retorna (GVG_PREPROCESSING_QUERY_v1)

Entrada: consulta em linguagem natural (pt‑BR). Saída: JSON estrito com campos:
- search_terms: termos positivos para a busca (alimentam embeddings/FTS).
- negative_terms: termos a excluir (alimentam o embedding de negação; nunca viram SQL).
- sql_conditions: lista de strings SQL em snake_case, com prefixos de tabela (c./ce.) coerentes com V1.
- explanation: breve justificativa.
- requires_join_embeddings: true se alguma condição usar campos de `contratacao_emb` (alias ce), p.ex. `ce.confidence` ou `ce.top_categories`.

Pontos‑chave de modelagem implementados no assistente:
- Datas são strings na base; toda condição temporal deve usar cast seguro: `to_date(NULLIF(c.data_encerramento_proposta,''),'YYYY-MM-DD') ...`.
- Dimensões temporais e defaults:
  - Encerramento: default para expressões genéricas (ex.: “em 2024”, “entre jan e mar 2025”).
  - Abertura: quando citado explicitamente.
  - Inclusão: quando frases como “recentes”, “inseridos”, “cadastrados” forem usadas.
- Valores (homologado vs estimado): se a consulta não especifica qual, aplicar OR entre ambos.
- Geografia: UFs em `c.unidade_orgao_uf_sigla`, municípios via `ILIKE` em `c.unidade_orgao_municipio_nome`.
- Administrativas: poder/esfera/modalidade/disputa em campos snake_case (`c.orgao_entidade_poder_id`, `c.modalidade_nome`, `c.modo_disputa_nome`, etc.).
- Categorias/IA: condições sobre `ce.confidence` e `ce.top_categories` exigem `requires_join_embeddings = true`.

Exemplo de saída (resumo):
```json
{
  "search_terms": "material escolar",
  "negative_terms": "uniformes",
  "sql_conditions": [
    "c.unidade_orgao_uf_sigla IN ('BA','PE','SE','AL','MA','PI','CE','RN','PB')",
    "(c.valor_total_homologado > 200000 OR c.valor_total_estimado > 200000)",
    "c.ano_compra = 2024",
    "ce.confidence > 0.8"
  ],
  "requires_join_embeddings": true
}
```

### Tabelas e campos relevantes no BDS1 (db/BDS1.txt)

- `public.contratacao` (alias c):
  - Identificador: `numero_controle_pncp` (chave de negócio; PK da tabela é `id_contratacao`).
  - Texto base FTS: `objeto_compra` (campo texto).
  - Datas TEXT: `data_abertura_proposta`, `data_encerramento_proposta`, `data_inclusao` (sempre usar `to_date(NULLIF(...),'YYYY-MM-DD')` em comparações).
  - Valores: `valor_total_homologado` (numeric) e `valor_total_estimado` (texto; tratado como numeric_text no schema consolidado; pode exigir cast em consultas específicas, mas o core evita depender disso no SQL gerado pelo assistente quando possível).
  - Geografia/órgão: `unidade_orgao_uf_sigla`, `unidade_orgao_municipio_nome`, `orgao_entidade_razao_social`.
  - Modalidade/disputa: `modalidade_id`, `modalidade_nome`, `modo_disputa_id`, `modo_disputa_nome`.
  - Poder/Esfera: `orgao_entidade_poder_id` (E/L/J), `orgao_entidade_esfera_id` (F/E/M).
  - Links e meta: `link_sistema_origem`, `usuario_nome`, etc.

- `public.contratacao_emb` (alias ce):
  - Chave de ligação: `numero_controle_pncp`.
  - Vetor de embedding: `embeddings` (pgvector 3072D, conforme embeddings 3‑large).
  - Metadados de IA: `confidence` (numeric), `top_categories` (array de códigos), `top_similarities` (array de strings/numéricos), `modelo_embedding`.

- `public.categoria` (alias cat):
  - Códigos e nomes por nível: `cod_cat`, `nom_cat`, `cod_nv0..cod_nv3`, `nom_nv0..nom_nv3`.
  - Vetor: `cat_embeddings` (pgvector 3072D) usado para similaridade de categorias.

Outras tabelas (contrato, item_contratacao, item_classificacao) não são usadas diretamente no fluxo atual do terminal.

### Como o core aplica as condições

- `gvg_preprocessing.SearchQueryProcessor` chama o Assistant e retorna o JSON acima.
- `gvg_search_core`:
  - Em `semantic_search`, `keyword_search` e `hybrid_search`, lê `sql_conditions` e concatena no WHERE com `AND ...` além do filtro de expirados. O core já utiliza `to_date(NULLIF(...),'YYYY-MM-DD')` ao aplicar filtros de data padrão.
  - `negative_terms` é combinado no embedding (via `get_negation_embedding`) e nunca vira cláusula SQL.
  - Se o JSON incluir `requires_join_embeddings=true`, as condições podem referenciar `ce.*`. O core já usa JOIN de `contratacao` com `contratacao_emb` nas buscas semântica/híbrida; na keyword, a consulta base é apenas `contratacao` — portanto, prefira condições ce.* com semântica/híbrida (ou ajuste a keyword para não depender de `ce.*`).
  - Abordagens por categorias usam diretamente `contratacao_emb.top_categories` para filtrar/interseccionar quando aplicável.

### Exemplos práticos de mapeamento

- Tempo genérico:
  - “junho de 2024” → `to_date(NULLIF(c.data_encerramento_proposta,''),'YYYY-MM-DD') BETWEEN to_date('2024-06-01','YYYY-MM-DD') AND to_date('2024-06-30','YYYY-MM-DD')`
  - “abertura em março 2025” → usar `data_abertura_proposta` no mesmo padrão de cast.
  - “encerrando hoje” → `to_date(NULLIF(c.data_encerramento_proposta,''),'YYYY-MM-DD') = CURRENT_DATE`

- Valores:
  - “acima de 500 mil” → `(c.valor_total_homologado > 500000 OR c.valor_total_estimado > 500000)`
  - “valor homologado abaixo de 50 mil” → `c.valor_total_homologado < 50000`

- Geografia/órgão:
  - “Nordeste” → `c.unidade_orgao_uf_sigla IN ('BA','PE','SE','AL','MA','PI','CE','RN','PB')`
  - “Vitória” → `c.unidade_orgao_municipio_nome ILIKE '%Vitória%'`

- Modalidade/Disputa:
  - “pregão eletrônico” → `c.modalidade_nome ILIKE '%pregão%eletrônico%'`
  - “disputa aberta” → `c.modo_disputa_nome ILIKE '%aberto%'`

- IA/Categorias:
  - “bem categorizados” → `ce.confidence > 0.8` (marcar `requires_join_embeddings=true`)
  - “categoria M001” → `'M001' = ANY(ce.top_categories)`

### Cuidados e limitações

- Não transformar `negative_terms` em SQL; eles são só vetoriais (subtração no embedding).
- As datas são TEXT: sempre fazer cast seguro (`to_date(NULLIF(...),'YYYY-MM-DD')`) em comparações.
- `valor_total_estimado` pode ser TEXT na base — o Assistant tende a gerar filtros que evitam CAST explícito; quando necessário, preferir regras sobre `valor_total_homologado` ou aplicar ambas as colunas com bom senso.
- Em buscas de palavras‑chave (FTS), as condições `ce.*` não se aplicam a menos que a query seja adaptada para JOIN — use semântica/híbrida quando precisar de `ce.*`.
- Campos/nomes em snake_case; o core injeta aliases legados para UI/export (
  ex.: `modalidadeNome`, `valortotalestimado`), mas as condições devem sempre usar snake_case.

Com isso, o vínculo entre o que o usuário escreve, o que o Assistant produz e o que o banco suporta fica explícito e auditável.
